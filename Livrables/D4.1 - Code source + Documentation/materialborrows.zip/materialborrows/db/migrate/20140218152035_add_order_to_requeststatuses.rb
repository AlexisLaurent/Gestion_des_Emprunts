class AddOrderToRequeststatuses < ActiveRecord::Migration
  def change
    add_column :requeststatuses, :order, :integer
  end
end
