class CreateMotivestatuses < ActiveRecord::Migration
  def change
    create_table :motivestatuses do |t|
      t.string :label

      t.timestamps
    end
  end
end
