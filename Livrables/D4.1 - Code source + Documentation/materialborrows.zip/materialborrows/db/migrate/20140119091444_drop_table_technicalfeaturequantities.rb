class DropTableTechnicalfeaturequantities < ActiveRecord::Migration
 def up
    drop_table :technicalfeaturequantities
  end

  def down
    raise ActiveRecord::IrreversibleMigration
  end
end
