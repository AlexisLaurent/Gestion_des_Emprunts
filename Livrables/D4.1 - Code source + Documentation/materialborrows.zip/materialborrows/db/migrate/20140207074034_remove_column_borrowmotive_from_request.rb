class RemoveColumnBorrowmotiveFromRequest < ActiveRecord::Migration
  def up
    remove_column :requests, :borrowmotive
  end
end
