class AddTechnicalfeatureIdToTechnicalfeaturesrequests < ActiveRecord::Migration
  def change
    add_column :technicalfeaturesrequests, :technicalfeature_id, :integer
  end
end
