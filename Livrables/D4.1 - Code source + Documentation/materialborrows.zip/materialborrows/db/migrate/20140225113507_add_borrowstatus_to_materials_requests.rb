class AddBorrowstatusToMaterialsRequests < ActiveRecord::Migration
  def change
    add_column :materials_requests, :borrowstatus, :string
  end
end
