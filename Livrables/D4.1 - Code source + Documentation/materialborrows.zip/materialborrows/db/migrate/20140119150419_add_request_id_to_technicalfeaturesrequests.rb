class AddRequestIdToTechnicalfeaturesrequests < ActiveRecord::Migration
  def change
    add_column :technicalfeaturesrequests, :request_id, :integer
  end
end
