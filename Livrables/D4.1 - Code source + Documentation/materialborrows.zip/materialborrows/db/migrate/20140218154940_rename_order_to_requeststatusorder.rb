class RenameOrderToRequeststatusorder < ActiveRecord::Migration
  def change
    rename_column :requeststatuses, :order, :requeststatusorder
  end
end
