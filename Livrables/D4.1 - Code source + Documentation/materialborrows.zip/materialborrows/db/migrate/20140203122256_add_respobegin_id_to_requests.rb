class AddRespobeginIdToRequests < ActiveRecord::Migration
  def change
    add_column :requests, :respobegin_id, :integer
  end
end
