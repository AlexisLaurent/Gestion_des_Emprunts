class AddBarcodeToMaterials < ActiveRecord::Migration
  def change
    add_column :materials, :barcode, :string
  end
end
