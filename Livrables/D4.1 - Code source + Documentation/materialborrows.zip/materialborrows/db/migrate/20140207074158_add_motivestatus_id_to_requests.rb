class AddMotivestatusIdToRequests < ActiveRecord::Migration
  def change
    add_column :requests, :motivestatus_id, :integer
  end
end
