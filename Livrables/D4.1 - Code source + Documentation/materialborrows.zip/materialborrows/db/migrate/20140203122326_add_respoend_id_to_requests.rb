class AddRespoendIdToRequests < ActiveRecord::Migration
  def change
    add_column :requests, :respoend_id, :integer
  end
end
