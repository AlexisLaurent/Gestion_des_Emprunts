class AddOrderToMaterialstatuses < ActiveRecord::Migration
  def change
    add_column :materialstatuses, :order, :integer
  end
end
