class CreateTechnicalfeaturesrequests < ActiveRecord::Migration
  def change
    create_table :technicalfeaturesrequests do |t|
      t.integer :borrowedquantity
      t.timestamps
    end
  end
end
