class RemoveColumnOrderFromMaterialstatuses < ActiveRecord::Migration
  def up
    remove_column :materialstatuses, :order
  end
end
