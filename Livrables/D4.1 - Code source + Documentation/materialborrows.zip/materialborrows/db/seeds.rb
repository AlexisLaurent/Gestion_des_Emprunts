# Clear the database
ActiveRecord::Base.establish_connection
ActiveRecord::Base.connection.tables.each do |table|
  next if table == 'schema_migrations'

  # SQLite
  ActiveRecord::Base.connection.execute("DELETE FROM #{table}")
end

# Table privileges 

admin_privilege = Privilege.create :label => 'Admin'
user_privilege = Privilege.create :label => 'User'

####################


# Table users 

romain = User.create :firstname => 'Romain', :lastname => 'Roufast', :email => 'romain.roufast@gmail.com', :password => 'secret' , :privilege => admin_privilege
alexis = User.create :firstname => 'Alexis', :lastname => 'Laurent', :email => 'alexis.laurent2@gmail.com', :password => 'secret' , :privilege => admin_privilege
suzy = User.create :firstname => 'Suzy', :lastname => 'Paeta', :email => 'suzy.paeta@gmail.com', :password => 'secret' , :privilege => admin_privilege
ben = User.create :firstname => 'Benjamin', :lastname => 'Volland', :email => 'ben@gmail.com', :password => 'secret' , :privilege => admin_privilege
christian = User.create :firstname => 'Christian', :lastname => 'Brel', :email => 'christian@gmail.com', :password => 'secret' , :privilege => admin_privilege
annemarie = User.create :firstname => 'Anne-Marie', :lastname => 'Dery Pinna', :email => 'annemarie@gmail.com', :password => 'secret' , :privilege => admin_privilege
alain = User.create :firstname => 'Alain', :lastname => 'Giboin', :email => 'alain@gmail.com', :password => 'secret' , :privilege => admin_privilege
philippe = User.create :firstname => 'Philippe', :lastname => 'Renevier', :email => 'philippe@gmail.com', :password => 'secret' , :privilege => admin_privilege

pierre = User.create :firstname => 'Pierre', :lastname => 'Martin', :email => 'pierre@gmail.com', :password => 'secret' , :privilege => user_privilege
paul = User.create :firstname => 'Paul', :lastname => 'Dupuis', :email => 'pierre@gmail.com', :password => 'secret' , :privilege => user_privilege

####################


#Table materialstatuses

matstatus1 = Materialstatus.create :label => 'Disponible'
matstatus2 = Materialstatus.create :label => 'En reserve'
matstatus3 = Materialstatus.create :label => 'Emprunte'
matstatus4 = Materialstatus.create :label => 'Inutilisable'


# Table materialtypes

type1 = Materialtype.create :label=>'Tablette tactile'
type1.save

type2 = Materialtype.create :label=>'Ordinateur'
type2.save

type3 = Materialtype.create :label=>'Smartphone'
type3.save

####################


# Table technicalfeatures

feature1 = Technicalfeature.create :os => 'Android', :name => 'Acer', :version => '2.4', :memory => '250', :ram => '8', :processorfrequency => '2.4', :materialtype => type1
feature2 = Technicalfeature.create :os => 'Android', :name => 'Asus', :version => '4.1', :memory => '16', :ram => '1', :processorfrequency => '1,2', :materialtype => type1
feature3 = Technicalfeature.create :os => 'iOS', :name => 'iPad Air', :version => '7.0.4', :memory => '64', :ram => '8', :processorfrequency => '2.4', :materialtype => type1
feature4 = Technicalfeature.create :os => 'Windows', :name => 'Surface Pro 2', :version => '8', :memory => '128', :ram => '4', :processorfrequency => 'Non-connue', :materialtype => type1

feature5 = Technicalfeature.create :os => 'Windows', :name => 'Portable HP Pavillon TouchSmart', :version => '8', :memory => '1000', :ram => '4', :processorfrequency => '2', :materialtype => type2
feature6 = Technicalfeature.create :os => 'iOS', :name => 'MacBook Air', :version => 'Mountain Lion', :memory => '128', :ram => '4', :processorfrequency => '1,3', :materialtype => type2
feature7 = Technicalfeature.create :os => 'Windows', :name => 'Toshiba Satellite', :version => '8', :memory => '500', :ram => '4', :processorfrequency => 'Non-connue', :materialtype => type2

feature8 = Technicalfeature.create :os => 'Android', :name => 'Samsung Galaxy S3', :version => '4.1', :memory => '16', :ram => '1', :processorfrequency => 'Non-connue', :materialtype => type3
feature9 = Technicalfeature.create :os => 'iOS', :name => 'iPhone 4S', :version => '7.0.4', :memory => '8', :ram => '1', :processorfrequency => 'Non-connue', :materialtype => type3
feature10 = Technicalfeature.create :os => 'Windows', :name => 'Nokia Lumia 520', :version => '8', :memory => '8', :ram => '1', :processorfrequency => 'Non-connue', :materialtype => type3

####################


# Table materials
mat1 = Material.create :serialnumber => 'JHFUER879GAA00', :guaranteeend => Date.new(2014, 01, 26), :anomaly => 'Ecran casse', :whobought => 'Polytech Nice', :technicalfeature => feature1, :barcode => "11110", :materialstatus => matstatus3 

(1..6).each do |i|
  Material.create :serialnumber => 'JHFUER879GAA0'+i.to_s(), :guaranteeend => Date.new(2014, 01, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature1, :barcode => "1111"+i.to_s(), :materialstatus => matstatus1 
end

(0..4).each do |i|
  Material.create :serialnumber => 'JHFUER879GAB0'+i.to_s(), :guaranteeend => Date.new(2014, 02, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature2, :barcode => "2222"+i.to_s(), :materialstatus => matstatus1
end

(0..4).each do |i|
  Material.create :serialnumber => 'JHFUER879GAC0'+i.to_s(), :guaranteeend => Date.new(2014, 03, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature3, :barcode => "3333"+i.to_s(), :materialstatus => matstatus1
end

(0..3).each do |i|
  Material.create :serialnumber => 'JHFUER879GAD0'+i.to_s(), :guaranteeend => Date.new(2014, 04, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature4, :barcode => "4444"+i.to_s(), :materialstatus => matstatus1
end

(0..3).each do |i|
  Material.create :serialnumber => 'JHFUER879GBA0'+i.to_s(), :guaranteeend => Date.new(2013, 05, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature5, :barcode => "5555"+i.to_s(), :materialstatus => matstatus1
end

(0..3).each do |i|
  Material.create :serialnumber => 'JHFUER879GBB0'+i.to_s(), :guaranteeend => Date.new(2013, 06, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature6, :barcode => "6666"+i.to_s(), :materialstatus => matstatus1
end

(0..3).each do |i|
  Material.create :serialnumber => 'JHFUER879GBC0'+i.to_s(), :guaranteeend => Date.new(2013, 07, 26), :anomaly => 'Batterie morte', :whobought => 'Polytech Nice', :technicalfeature => feature7, :barcode => "7777"+i.to_s(), :materialstatus => matstatus1
end

(0..5).each do |i|
  Material.create :serialnumber => 'JHFUER879GCA0'+i.to_s(), :guaranteeend => Date.new(2012, 05, 13), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature8, :barcode => "8888"+i.to_s(), :materialstatus => matstatus1
end

(0..5).each do |i|
  Material.create :serialnumber => 'JHFUER879GCB0'+i.to_s(), :guaranteeend => Date.new(2012, 07, 24), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature9, :barcode => "9999"+i.to_s(), :materialstatus => matstatus1
end

(0..3).each do |i|
  Material.create :serialnumber => 'JHFUER879GCC0'+i.to_s(), :guaranteeend => Date.new(2012, 10, 26), :anomaly => 'Aucune', :whobought => 'Polytech Nice', :technicalfeature => feature10, :barcode => "0000"+i.to_s(), :materialstatus => matstatus1
end


feature1.borrowablequantity = '5'
feature2.borrowablequantity = '5'
feature3.borrowablequantity = '5'
feature4.borrowablequantity = '4'
feature5.borrowablequantity = '4'
feature6.borrowablequantity = '4'
feature7.borrowablequantity = '4'
feature8.borrowablequantity = '6'
feature9.borrowablequantity = '6'
feature10.borrowablequantity = '4'

feature1.save
feature2.save
feature3.save
feature4.save
feature5.save
feature6.save
feature7.save
feature8.save
feature9.save
feature10.save

####################


# Table complexdatetypes

compldatetype1 = Complexdatetype.create :label => 'RDV debut'
compldatetype1.save

compldatetype2 = Complexdatetype.create :label => 'RDV fin'
compldatetype2.save

compldatetype3 = Complexdatetype.create :label => 'Emprunt debut'
compldatetype3.save

compldatetype4 = Complexdatetype.create :label => 'Emprunt fin'
compldatetype4.save

####################


# Table requeststatuses

reqstat1 = Requeststatus.create :label => 'En attente', :requeststatusorder => '1'
reqstat1.save

reqstat2 = Requeststatus.create :label => 'Terminee', :requeststatusorder => '4'
reqstat2.save

reqstat3 = Requeststatus.create :label => 'Refusee', :requeststatusorder => '5'
reqstat3.save

reqstat4 = Requeststatus.create :label => 'Validee', :requeststatusorder => '2'
reqstat4.save

reqstat5 = Requeststatus.create :label => 'En cours', :requeststatusorder => '3'
reqstat5.save

####################

# Table requeststatuses

motive1 = Motivestatus.create :label => 'Cours'

motive2 = Motivestatus.create :label => 'TP'

motive3 = Motivestatus.create :label => 'Projet'

motive4 = Motivestatus.create :label => 'Personnel'


####################

# Table requests

req1 = Request.create :motivestatus => motive1, :user => romain, :requeststatus => reqstat1
req2 = Request.create :motivestatus => motive2, :user => alexis, :requeststatus => reqstat5, :respobegin => christian
req3 = Request.create :motivestatus => motive3, :user => suzy, :requeststatus => reqstat4, :respobegin => christian
req4 = Request.create :motivestatus => motive4, :user => romain, :requeststatus => reqstat3, :refusalmotive => "Pas d'emprunt personnel pour cette periode"
req5 = Request.create :motivestatus => motive1, :user => alexis, :requeststatus => reqstat2, :respobegin => christian
req6 = Request.create :motivestatus => motive2, :user => suzy, :requeststatus => reqstat1
req7 = Request.create :motivestatus => motive3, :user => romain, :requeststatus => reqstat1
req8 = Request.create :motivestatus => motive2, :user => alexis, :requeststatus => reqstat1
req9 = Request.create :motivestatus => motive1, :user => romain, :requeststatus => reqstat1
req10 = Request.create :motivestatus => motive2, :user => romain, :requeststatus => reqstat2, :respobegin => christian
req11 = Request.create :motivestatus => motive3, :user => suzy, :requeststatus => reqstat2, :respobegin => christian


compldate1 = Complexdate.create :cdate => Date.new(2014, 03, 17), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req1, :complexdatetype => compldatetype3
compldate2 = Complexdate.create :cdate => Date.new(2014, 03, 19), :beginhour => Time.now, :endhour => Time.now, :request => req1, :complexdatetype => compldatetype4
compldate3 = Complexdate.create :cdate => Date.new(2014, 01, 17), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req1, :complexdatetype => compldatetype1
compldate4 = Complexdate.create :cdate => Date.new(2014, 01, 19), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req1, :complexdatetype => compldatetype2

compldate1 = Complexdate.create :cdate => Date.new(2014, 03, 17), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req1, :complexdatetype => compldatetype3
compldate2 = Complexdate.create :cdate => Date.new(2014, 03, 19), :beginhour => Time.now, :endhour => Time.now, :request => req1, :complexdatetype => compldatetype4
compldate3 = Complexdate.create :cdate => Date.new(2014, 01, 26), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req1, :complexdatetype => compldatetype1
compldate4 = Complexdate.create :cdate => Date.new(2014, 01, 26), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req1, :complexdatetype => compldatetype2

compldate5 = Complexdate.create :cdate => Date.new(2014, 01, 26), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req2, :complexdatetype => compldatetype1
compldate6 = Complexdate.create :cdate => Date.new(2014, 03, 19), :beginhour => Time.now, :endhour => Time.now, :request => req2, :complexdatetype => compldatetype2
compldate7 = Complexdate.create :cdate => Date.new(2014, 01, 26), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req2, :complexdatetype => compldatetype3
compldate8 = Complexdate.create :cdate => Date.new(2014, 01, 26), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req2, :complexdatetype => compldatetype4

compldate9 = Complexdate.create :cdate => Date.new(2014, 01, 19), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req3, :complexdatetype => compldatetype1
compldate10 = Complexdate.create :cdate => Date.new(2014, 01, 20), :beginhour => Time.now, :endhour => Time.now, :request => req3, :complexdatetype => compldatetype2
compldate11 = Complexdate.create :cdate => Date.new(2014, 01, 19), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req3, :complexdatetype => compldatetype3
compldate12 = Complexdate.create :cdate => Date.new(2014, 01, 20), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req3, :complexdatetype => compldatetype4

compldate13 = Complexdate.create :cdate => Date.new(2014, 02, 15), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req4, :complexdatetype => compldatetype1
compldate14 = Complexdate.create :cdate => Date.new(2014, 02, 26), :beginhour => Time.now, :endhour => Time.now, :request => req4, :complexdatetype => compldatetype2
compldate15 = Complexdate.create :cdate => Date.new(2014, 02, 15), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req4, :complexdatetype => compldatetype3
compldate16 = Complexdate.create :cdate => Date.new(2014, 02, 26), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req4, :complexdatetype => compldatetype4

compldate17 = Complexdate.create :cdate => Date.new(2014, 02, 25), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req5, :complexdatetype => compldatetype1
compldate18 = Complexdate.create :cdate => Date.new(2014, 02, 28), :beginhour => Time.now, :endhour => Time.now, :request => req5, :complexdatetype => compldatetype2
compldate19 = Complexdate.create :cdate => Date.new(2014, 02, 25), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req5, :complexdatetype => compldatetype3
compldate20 = Complexdate.create :cdate => Date.new(2014, 02, 28), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req5, :complexdatetype => compldatetype4

compldate21 = Complexdate.create :cdate => Date.new(2014, 03, 5), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req6, :complexdatetype => compldatetype1
compldate22 = Complexdate.create :cdate => Date.new(2014, 03, 10), :beginhour => Time.now, :endhour => Time.now, :request => req6, :complexdatetype => compldatetype2
compldate23 = Complexdate.create :cdate => Date.new(2014, 03, 5), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req6, :complexdatetype => compldatetype3
compldate24 = Complexdate.create :cdate => Date.new(2014, 03, 10), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req6, :complexdatetype => compldatetype4

compldate25 = Complexdate.create :cdate => Date.new(2014, 03, 20), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req7, :complexdatetype => compldatetype1
compldate26 = Complexdate.create :cdate => Date.new(2014, 03, 22), :beginhour => Time.now, :endhour => Time.now, :request => req7, :complexdatetype => compldatetype2
compldate27 = Complexdate.create :cdate => Date.new(2014, 03, 20), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req7, :complexdatetype => compldatetype3
compldate28 = Complexdate.create :cdate => Date.new(2014, 03, 22), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req7, :complexdatetype => compldatetype4

compldate29 = Complexdate.create :cdate => Date.new(2014, 04, 2), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req8, :complexdatetype => compldatetype1
compldate30 = Complexdate.create :cdate => Date.new(2014, 04, 3), :beginhour => Time.now, :endhour => Time.now, :request => req8, :complexdatetype => compldatetype2
compldate31 = Complexdate.create :cdate => Date.new(2014, 04, 2), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req8, :complexdatetype => compldatetype3
compldate32 = Complexdate.create :cdate => Date.new(2014, 04, 3), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req8, :complexdatetype => compldatetype4

compldate33 = Complexdate.create :cdate => Date.new(2014, 04, 7), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req9, :complexdatetype => compldatetype1
compldate34 = Complexdate.create :cdate => Date.new(2014, 04, 14), :beginhour => Time.now, :endhour => Time.now, :request => req9, :complexdatetype => compldatetype2
compldate35 = Complexdate.create :cdate => Date.new(2014, 04, 7), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req9, :complexdatetype => compldatetype3
compldate36 = Complexdate.create :cdate => Date.new(2014, 04, 14), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req9, :complexdatetype => compldatetype4

compldate37 = Complexdate.create :cdate => Date.new(2014, 03, 7), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req10, :complexdatetype => compldatetype1
compldate38 = Complexdate.create :cdate => Date.new(2014, 03, 14), :beginhour => Time.now, :endhour => Time.now, :request => req10, :complexdatetype => compldatetype2
compldate39 = Complexdate.create :cdate => Date.new(2014, 03, 7), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req10, :complexdatetype => compldatetype3
compldate40 = Complexdate.create :cdate => Date.new(2014, 03, 14), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req10, :complexdatetype => compldatetype4

compldate41 = Complexdate.create :cdate => Date.new(2014, 04, 7), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req11, :complexdatetype => compldatetype1
compldate42 = Complexdate.create :cdate => Date.new(2014, 04, 14), :beginhour => Time.now, :endhour => Time.now, :request => req11, :complexdatetype => compldatetype2
compldate43 = Complexdate.create :cdate => Date.new(2014, 04, 7), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req11, :complexdatetype => compldatetype3
compldate44 = Complexdate.create :cdate => Date.new(2014, 04, 14), :beginhour => Time.now, :endhour => Time.now, :precisehour => Time.now, :request => req11, :complexdatetype => compldatetype4
####################

# Table technicalfeaturerequests

techreq1 = Technicalfeaturesrequest.create :technicalfeature => feature1, :request => req1, :borrowedquantity => '2'
techreq2 = Technicalfeaturesrequest.create :technicalfeature => feature5, :request => req1, :borrowedquantity => '1'

techreq3 = Technicalfeaturesrequest.create :technicalfeature => feature3, :request => req2, :borrowedquantity => '1'
techreq4 = Technicalfeaturesrequest.create :technicalfeature => feature4, :request => req2, :borrowedquantity => '1'

techreq5 = Technicalfeaturesrequest.create :technicalfeature => feature7, :request => req3, :borrowedquantity => '2'
techreq6 = Technicalfeaturesrequest.create :technicalfeature => feature8, :request => req3, :borrowedquantity => '3'

techreq7 = Technicalfeaturesrequest.create :technicalfeature => feature6, :request => req4, :borrowedquantity => '1'
techreq8 = Technicalfeaturesrequest.create :technicalfeature => feature10, :request => req4, :borrowedquantity => '1'

techreq9 = Technicalfeaturesrequest.create :technicalfeature => feature2, :request => req5, :borrowedquantity => '1'
techreq10 = Technicalfeaturesrequest.create :technicalfeature => feature9, :request => req5, :borrowedquantity => '1'

techreq11 = Technicalfeaturesrequest.create :technicalfeature => feature3, :request => req6, :borrowedquantity => '1'
techreq12 = Technicalfeaturesrequest.create :technicalfeature => feature5, :request => req6, :borrowedquantity => '1'

techreq13 = Technicalfeaturesrequest.create :technicalfeature => feature6, :request => req7, :borrowedquantity => '1'
techreq14 = Technicalfeaturesrequest.create :technicalfeature => feature10, :request => req7, :borrowedquantity => '1'

techreq15 = Technicalfeaturesrequest.create :technicalfeature => feature8, :request => req8, :borrowedquantity => '1'
techreq16 = Technicalfeaturesrequest.create :technicalfeature => feature7, :request => req8, :borrowedquantity => '1'

techreq17 = Technicalfeaturesrequest.create :technicalfeature => feature9, :request => req9, :borrowedquantity => '1'
techreq18 = Technicalfeaturesrequest.create :technicalfeature => feature10, :request => req9, :borrowedquantity => '1'

mat1.requests << req5
mat1.requests << req10
mat1.requests << req11
mat1.requests << req2
mat1.save
