require 'test_helper'

class MaterialtypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
