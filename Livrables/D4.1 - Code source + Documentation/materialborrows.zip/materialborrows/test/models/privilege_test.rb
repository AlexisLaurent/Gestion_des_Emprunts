require 'test_helper'

class PrivilegeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
