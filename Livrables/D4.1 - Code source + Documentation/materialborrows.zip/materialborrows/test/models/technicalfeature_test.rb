require 'test_helper'

class TechnicalfeatureTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
