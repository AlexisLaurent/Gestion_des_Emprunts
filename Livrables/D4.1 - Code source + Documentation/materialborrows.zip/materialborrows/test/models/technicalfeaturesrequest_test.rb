require 'test_helper'

class TechnicalfeaturesrequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
