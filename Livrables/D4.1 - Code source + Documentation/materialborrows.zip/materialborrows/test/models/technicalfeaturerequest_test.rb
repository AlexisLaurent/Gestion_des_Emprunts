require 'test_helper'

class TechnicalfeaturerequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
