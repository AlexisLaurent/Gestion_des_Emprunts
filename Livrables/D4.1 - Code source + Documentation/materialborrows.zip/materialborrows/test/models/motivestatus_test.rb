require 'test_helper'

class MotivestatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
