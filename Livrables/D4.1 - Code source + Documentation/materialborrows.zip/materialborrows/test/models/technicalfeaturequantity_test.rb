require 'test_helper'

class TechnicalfeaturequantityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
