require 'test_helper'

class MaterialstatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
