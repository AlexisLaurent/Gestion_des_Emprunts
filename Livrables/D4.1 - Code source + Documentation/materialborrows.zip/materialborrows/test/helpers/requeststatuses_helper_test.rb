require 'test_helper'

class RequeststatusesHelperTest < ActionView::TestCase
end
