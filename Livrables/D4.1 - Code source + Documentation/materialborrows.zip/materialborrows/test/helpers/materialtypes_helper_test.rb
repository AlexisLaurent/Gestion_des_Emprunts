require 'test_helper'

class MaterialtypesHelperTest < ActionView::TestCase
end
