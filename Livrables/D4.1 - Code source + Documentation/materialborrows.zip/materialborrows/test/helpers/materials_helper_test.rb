require 'test_helper'

class MaterialsHelperTest < ActionView::TestCase
end
