require 'test_helper'

class TechnicalfeaturesHelperTest < ActionView::TestCase
end
