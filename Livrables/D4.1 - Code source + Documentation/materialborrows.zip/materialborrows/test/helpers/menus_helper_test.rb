require 'test_helper'

class MenusHelperTest < ActionView::TestCase
end
