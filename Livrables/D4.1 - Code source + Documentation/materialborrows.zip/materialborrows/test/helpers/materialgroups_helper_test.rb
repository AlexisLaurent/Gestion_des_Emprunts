require 'test_helper'

class MaterialgroupsHelperTest < ActionView::TestCase
end
