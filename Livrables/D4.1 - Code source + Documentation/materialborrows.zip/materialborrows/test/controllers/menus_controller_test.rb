require 'test_helper'

class MenusControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
