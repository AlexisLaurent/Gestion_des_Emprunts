require 'test_helper'

class MaterialgroupsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
