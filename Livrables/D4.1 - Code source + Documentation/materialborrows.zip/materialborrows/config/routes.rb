Materialborrows::Application.routes.draw do
  
	get "carts/add", :controller=>"carts", :action=>"add"
	get "carts/clear", :controller=>"carts", :action=>"clear"
	get "carts/remove", :controller=>"carts", :action=>"remove"
	get "materials/by_type", :controller=>"materials", :action=>"by_type"
	get "materials/check_available", :controller=>"materials", :action=>"check_available"
	get "materials/check_period", :controller=>"materials", :action=>"check_period"
	get "materials/manage", :controller=>"materials", :action=>"manage"
	get "requests/by_status", :controller=>"requests", :action=>"by_status"
	get "requests/new", :controller=>"requests", :action=>"new"
	get "requests/newtwo", :controller=>"requests", :action=>"newtwo"
	get "requests/requestcomplet", :controller=>"requests", :action=>"requestcomplet"
	get "requests/manage", :controller=>"requests", :action=>"manage"
	get "requests/requestcomplet_finished", :controller=>"requests", :action=>"requestcomplet_finished"
	get "requests/requestcomplet_waiting", :controller=>"requests", :action=>"requestcomplet_waiting"
	get "requests/requestcomplet_pending", :controller=>"requests", :action=>"requestcomplet_pending"
	get "requests/requestcomplet_validated", :controller=>"requests", :action=>"requestcomplet_validated"
	get "requests/requestcomplet_refused", :controller=>"requests", :action=>"requestcomplet_refused"
	get "requests/calendar", :controller=>"requests", :action=>"calendar"
	get "users/get_id", :controller=>"users", :action=>"get_id"
	
	root :to => "requests#new"
	resources :users
	resource :session, :only => [:new, :create, :destroy]
	get '/login' => "sessions#new", :as => "login"
	get '/logout' => "sessions#destroy", :as => "logout"
	
	get '/requests/newtwo' => "requests#newtwo"
	get '/requests/new' => "requests#new"
	
	get '/materials/manage' => "materials#manage"
	get '/requests/manage' => "requests#manage"
	get '/requests/manage/:status' => "requests#manage"

	get '/requests/:type' => "requests#request_type"
	get '/requests/:type/:id' => "requests#request_type"

	get '/materialtypes/all' => "materialtypes#all"

	get '/materials/all' => "materials#all"
	get '/materials/all/:id' => "materials#all"
	
  get '/materials/autocomplete' => "materials#autocomplete"

	get '/materials/check_material' => "materials#check_material"

	get '/materials/show_material' => "materials#show_material"

	get '/materials/add_material' => "materials#add_material"

	get '/materials/del_material' => "materials#del_material"
	
	get '/materialtypes/types' => "materialtypes#types"

	get '/requests/motive' => "requests#motive"
	
	get '/technicalfeatures/all/:id' => "technicalfeatures#all"
	
  get '/technicalfeatures/add/:id' => "technicalfeatures#add"
  
  get '/technicalfeatures/del/:id' => "technicalfeatures#del"

	post '/requests/update'
	post '/users/get_id'

	post '/requests/create_mobile' => "requests#create_mobile"

	post '/requests/refuse_request' => "requests#refuse_request"

	post '/requests/valide_request' => "requests#valide_request"
	
	resources :complexdates
	resources :technicalfeatures
	resources :materials
	resources :requests do
	  member do
	    post :notify_respo
	  end
	end
	resources :materialgroups
	resources :materialtypes
	resources :carts
	
end
