# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Materialborrows::Application.config.secret_key_base = 'f286e98291a08320b564158bc0865c37f35f568d860b79c0ccc37edd60eede5dc9e90aa61f41c38add83e87c3090e5dda2e8b17205aab64a845ad0c110822653'
