# Be sure to restart your server when you modify this file.

Materialborrows::Application.config.session_store :cookie_store, key: '_materialborrows_session'
