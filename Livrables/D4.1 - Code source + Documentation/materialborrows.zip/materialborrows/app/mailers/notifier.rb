class Notifier < ActionMailer::Base
  default from: "polytechemprunts@gmail.com"

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.notifier.email_respo.subject
  #
  def email_respo(req, email_cur_user)
    @request = req
    @email_cur_user = email_cur_user
    
    mail to: @email_cur_user, :subject => "Demande d'emprunt de materiel"
  end
end
