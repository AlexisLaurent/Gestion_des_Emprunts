class Cart < ActiveRecord::Base
  
  has_many :cartlistmaterials, -> {order('created_at ASC')}
  has_many :cartitems, -> {order('name ASC')}, :through => :cartlistmaterials, :source => :technicalfeature
 
  def empty?
	return cartlistmaterials.empty?
  end
  
  def clear
	return cartlistmaterials.delete_all
  end
  
  def removeAll(technicalFeatureId)
	cartlistmaterials.find_by_technicalfeature_id(technicalFeatureId).delete()
  end
  
  def remove(technicalFeatureId, qty)
	qty = cartlistmaterials.find_by_technicalfeature_id(technicalFeatureId).quantity - qty
	cartlistmaterials.find_by_technicalfeature_id(technicalFeatureId).update_attributes(:quantity => qty)
  end
  
  def countByTechnicalFeature(technicalFeatureId)
	return cartlistmaterials.find_by_technicalfeature_id(technicalFeatureId).quantity
  end
  
  def count
	return cartlistmaterials.count
  end
  
end
