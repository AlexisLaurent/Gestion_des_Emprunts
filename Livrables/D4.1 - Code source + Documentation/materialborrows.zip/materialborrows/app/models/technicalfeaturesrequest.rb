class Technicalfeaturesrequest < ActiveRecord::Base
  belongs_to :technicalfeature
  belongs_to :request
end
