class Technicalfeature < ActiveRecord::Base
  
  has_many :materials
  belongs_to :materialtype
    
  has_many :cartlistmaterials
  has_many :techitems, :through => :cartlistmaterials, :source => :cart
  
  has_many :technicalfeaturesrequests
  has_many :req, :through => :technicalfeaturerequests, :source => :request

end