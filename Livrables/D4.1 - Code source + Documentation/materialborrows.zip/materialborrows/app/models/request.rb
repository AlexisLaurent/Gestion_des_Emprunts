class Request < ActiveRecord::Base	
  
  validates_presence_of :motivestatus

  # Relations
	belongs_to :user, :class_name => User
	belongs_to :respobegin, :class_name => User
	belongs_to :respoend, :class_name => User
	
	has_many :complexdates
	has_and_belongs_to_many :materials
	has_many :materials_requests
	belongs_to :requeststatus
	belongs_to :motivestatus
	
	has_many :technicalfeaturesrequests
	has_many :techfeatures, :through => :technicalfeaturerequests, :source => :technicalfeature
	
	def start_date
		complexdates.each do |date|
			return date if date.complexdatetype.label == 'Emprunt debut'
		end
		return nil
	end
	
	def end_date
		complexdates.each do |date|
			return date if date.complexdatetype.label == 'Emprunt fin'
		end
		return nil
	end
end
