class MaterialsController < ApplicationController
  before_action :check_isadmin
  # GET /materials
  # GET /materials.json    
  def index
 
  end

  def manage
    
  end
  
  # GET /materials/new
  # GET /materials/new.json  
  def new  
  end
  
  def update
    @type = nil
    if Materialtype.find_by_label(params[:type]) == nil
      @type = Materialtype.new(:label => params[:type])
    end
     @tech = Technicalfeature.find_by(
        :materialtype => Materialtype.find_by_label(params[:type]), 
        :os => params[:os],
        :name => params[:name],
        :version => params[:version],
        :memory => params[:memory],
        :ram => params[:ram],
        :processorfrequency => params[:processorfrequency]
        )
        
     if @tech == nil 
        @tech = Technicalfeature.new(
        :materialtype => Materialtype.find_by_label(params[:type]), 
        :os => params[:os],
        :name => params[:name],
        :version => params[:version],
        :memory => params[:memory],
        :ram => params[:ram],
        :processorfrequency => params[:processorfrequency],
        :borrowablequantity => 0
        )
     end
        @material = Material.find(params[:id])
        @material.serialnumber = params[:serialnumber]
        @material.guaranteeend = params[:guaranteeend]
        
        if params.has_key?(:anomaly)
          @material.anomaly = params[:anomaly]
        else
          @material.anomaly = "Aucune"
        end
        
        if params.has_key?(:unusable)
          @material.materialstatus = Materialstatus.find_by_label("Inutilisable")
        else
          @material.materialstatus = Materialstatus.find_by_label("Disponible") 
          @tech.borrowablequantity =  @tech.borrowablequantity + 1
        end
      
        @material.whobought = params[:whobought]
        @material.barcode = params[:barcode]
        @material.technicalfeature = @tech
        
        if @type.save && @tech.save && @material.save
          redirect_to '/materials/manage', notice: "Le materiel a ete mis a jour."
        else
          redirect_to '/materials/manage', alert: "Le materiel n'a pas pu etre mis a jour."
        end
  end
  
  def create
    
    @type = nil
    
     if Materialtype.find_by_label(params[:type]) == nil
       
      @type = Materialtype.new(:label => params[:type])
      
    end

      @tech = Technicalfeature.find_by(
        :materialtype => Materialtype.find_by_label(params[:type]), 
        :os => params[:os],
        :name => params[:name],
        :version => params[:version],
        :memory => params[:memory],
        :ram => params[:ram],
        :processorfrequency => params[:processorfrequency]
        )
     
      if @tech == nil 
        @tech = Technicalfeature.new()
        @tech.materialtype = Materialtype.find_by_label(params[:type])
        @tech.os = params[:os]
        @tech.name = params[:name]
        @tech.version = params[:version]
        @tech.memory = params[:memory]
        @tech.ram = params[:ram]
        @tech.processorfrequency = params[:processorfrequency]
        @tech.borrowablequantity = 0
      end
        
      # Material
      @material = Material.new()
      @material.materialstatus = Materialstatus.find_by_label('Disponible')
      @material.serialnumber = params[:serialnumber]
      @material.guaranteeend = params[:guaranteeend]
      
      if params.has_key?(:anomaly)
        @material.anomaly = params[:anomaly]     
      else
        @material.anomaly = "Aucune"
      end
      
      if params.has_key?(:unusable)
        @material.materialstatus = Materialstatus.find_by_label("Inutilisable")
      else
        @material.materialstatus = Materialstatus.find_by_label("Disponible") 
        @tech.borrowablequantity =  @tech.borrowablequantity + 1
      end

      @material.whobought = params[:whobought]
      @material.barcode = params[:barcode]
      @material.technicalfeature = @tech

      if @type.save && @tech.save && @material.save
          redirect_to '/materials/manage', notice: "Le materiel a ete correctement ajoute."
      else
          redirect_to '/materials/manage', alert: "Le materiel n'a pas ete ajoute."
      end
  end

  # GET /materials/1
  # GET /materials/1.json 
  def show
    @material = Material.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @material }
    end    
  end  
  
  def check_material
    @material = Material.find_by(:barcode => params[:barcode])
    if @material == nil
      @material = Material.new
      redirect_to :controller => 'materials', :action => 'add_material', :barcode => params[:barcode]
    else
      redirect_to :controller => 'materials', :action => 'show_material', :barcode => params[:barcode]
    end
  end
  
  def show_material
    @material = Material.find_by(:barcode => params[:barcode])
    @reqs = Array.new
    
    @material.requests.each do |req|
      @reqs << { :name => req.user.lastname , :deb => req.start_date.cdate, :fin => req.end_date.cdate}
    end
    
    @reqs.sort_by! {|u| u[:fin]}
    @reqs = @reqs.reverse

    respond_to do |format|
        format.html { render :partial => "show_material", :layout=>false } 
    end
  end
  
  def del_material
    @material = Material.find_by_id(params[:id])
    if @material.delete
      redirect_to :controller => 'materials', :action => 'add_material'
    else
      redirect_to :controller => 'materials', :action => 'show_material', :barcode => params[:barcode]
    end
  end
  
  def add_material
    @material = Material.new()
    
    @types = Materialtype.all
    
     if params.has_key?(:type)
        type = @types.find_by(:label => params[:type])
      else
        type = @types.first
      end
      
    @names = Technicalfeature.where(:materialtype => type).select(:name).uniq

    
    if params.has_key?(:id)
        @material = Material.find_by_id(params[:id])
    end
    respond_to do |format|
        format.html { render :partial => "add_material", :layout=>false } 
    end
  end
  
  def autocomplete
    types = Array.new
    names = Array.new
    os = Array.new
    versions = Array.new
    memorys = Array.new
    rams = Array.new
    whoboughts = Array.new
    processorfrequencys = Array.new
    
   Materialtype.all.each do |i|
       types << i.label
    end

    if Materialtype.find_by_label(params[:type]) != nil
    
      mat = Materialtype.find_by_label(params[:type])
      techs = Technicalfeature.where(:materialtype => mat)
      
      techs.select(:name).uniq.each do |i|
        names << i.name
      end
      
      techs.select(:os).uniq.each do |i|
        os << i.os
      end
   
      techs.select(:version).uniq.each do |i|
        versions << i.version
      end
     
      techs.select(:memory).uniq.each do |i|
        memorys << i.memory.to_s()
      end
     
      techs.select(:ram).uniq.each do |i|
        rams << i.ram.to_s()
      end
  
      techs.select(:processorfrequency).uniq.each do |i|
        processorfrequencys << i.processorfrequency.to_s()
      end
  
      Material.select(:whobought).uniq.each do |i|
        whoboughts << i.whobought
      end
    end
    
    res = [ types, names, os, versions, memorys, rams, processorfrequencys, whoboughts]
    respond_to do |format|
      format.json { render json: res }
    end
  end

  # Check if materials of the current_cart would be available on this day
  def check_available
  	# create a ruby date object
  	date = Date.new(params[:year].to_i(), params[:month].to_i(), params[:day].to_i())
  	
  	# get all the requests including the day
  	#requests = Request.where(:requeststatus != 'Terminee').where(:requeststatus != 'Refusee')
  	requests = Request.all
	availability = Hash.new
	
  	# loop on the requests
  	requests.each do |request|
  		if request.start_date != nil && request.end_date != nil && request.start_date.cdate <= date && request.end_date.cdate >= date
  			current_cart.cartitems.each do |technicalfeature|
				if (technicalfeaturesrequest = request.technicalfeaturesrequests.find_by_technicalfeature_id(technicalfeature.id)) != nil
					bqty = technicalfeaturesrequest.borrowedquantity
					availability[technicalfeature.id] = (availability[technicalfeature.id] == nil) ? bqty : availability[technicalfeature.id] + bqty
				end
			end
  		end
  	end
	features = []
	availability.each do |a|
		features << {:id=>a[0], :name=>current_cart.cartitems.find_by_id(a[0]).name, :alreadyBorrowed=>a[1], :wantedQty=>current_cart.cartlistmaterials.find_by_technicalfeature_id(a[0]).quantity, :borrowableQty=>current_cart.cartitems.find_by_id(a[0]).borrowablequantity}
	end
	information = {:features=>features, :day=>params[:day], :month=>(params[:month].to_i()-1)}
  	respond_to do |format|
  		format.json { render :json => information }
  	end
  end
  
  # Check if materials of the current_cart would be available on a period
  def check_period
  
	# Construct the dates
	startDateBegin = DateTime.new(params[:startYear].to_i(), params[:startMonth].to_i(), params[:startDay].to_i(), params[:hour1Start].to_i(), 0, 0)
	startDateEnd = DateTime.new(params[:startYear].to_i(), params[:startMonth].to_i(), params[:startDay].to_i(), params[:hour2Start].to_i(), 0, 0)
	endDateBegin = DateTime.new(params[:stopYear].to_i(), params[:stopMonth].to_i(), params[:stopDay].to_i(), params[:hour1End].to_i(), 0, 0)
	endDateEnd = DateTime.new(params[:stopYear].to_i(), params[:stopMonth].to_i(), params[:stopDay].to_i(), params[:hour2End].to_i(), 0, 0)
	
	# Check the beginning dates
	if startDateBegin >= startDateEnd
		render status: 200, json: {:status=>0, :notice=>"Le creneau concernant la date de debut n'est pas valide"} and return
	end
	
	# Check the end dates
	if endDateBegin >= endDateEnd
		render status: 200, json: {:status=>0, :notice=>"Le creneau concernant la date de fin n'est pas valide"} and return
	end	
	
	# Get all the requests inside the given period
	#statuses = Requeststatus.where(label: ['En attente','En cours'])
	statuses = Requeststatus.find_all_by_label(['En attente','En cours'])
	requests = Request.find_all_by_requeststatus_id(statuses)
	
	# Iterate on each request
	requests.each do |request|
		puts "______+++ " + req.to_s()
	end
	
	# JSON returned string
	results = {:notice=>startDateBegin}
	
	# Check if the end date is greater than the start date
	if startDateEnd < endDateBegin
		#JSONString << :status=>"1"
	else
		#JSONString << :status=>"0"
	end
  
	respond_to do |format|
  		format.json { render :json => results }
  	end
	
  end
  
  def by_type
	 @ids = params[:ids]
	 respond_to do |format|
		format.html { render :partial=>"by_type", :layout=>false  }
	 end
	end
  
  def all
    materials = Array.new
    mats = Material.all
    if (params.has_key?(:id))
      tech = Technicalfeature.find(params[:id])
      mats = Material.where(:technicalfeature => tech)
    end
    mats.each do |item|
      if item.materialstatus == Materialstatus.find_by_label("Emprunte")
        req = item.requests.find_by(:requeststatus => Requeststatus.find_by_label("En cours"))
        borrower = req.user
        materials << { :mat => item, :status => Materialstatus.find(item.materialstatus).label, :borrower => borrower}
      else
        materials << { :mat => item, :status => Materialstatus.find(item.materialstatus).label}
      end
    end
    
    respond_to do |format|
      format.json { render json: materials}
    end
  end
  
end
