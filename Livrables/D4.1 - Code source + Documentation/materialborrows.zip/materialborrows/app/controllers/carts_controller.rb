class CartsController < ApplicationController
  before_action :set_cart, only: [:show, :edit, :update, :destroy]
  before_action :check_availability, only: [:add]

  # GET /carts
  # GET /carts.json
  def index
  end

  # GET /carts/1
  # GET /carts/1.json
  def show
	@cart = current_cart
  end

  # GET /carts/new
  def new
    @cart = Cart.new
  end
  
  def add	
	if @item
		q = @item.quantity + @qty
		@item.update_attributes(:quantity => q)
	else
		current_cart.cartlistmaterials << Cartlistmaterial.create( :cart_id=>current_cart.id, :quantity=>@qty, :technicalfeature_id=>params[:id_feature])
	end
	render :partial=>'show'
  end
  
  def clear
	current_cart.clear	
	render :partial=>'show'
  end
  
  def remove
	qty = params[:qty]
	if (qty != nil  && qty.to_i() > 0 && current_cart.countByTechnicalFeature(params[:id_feature]) > 1)
		current_cart.remove(params[:id_feature], qty.to_i())
	else
		current_cart.removeAll(params[:id_feature])
	end
	render :partial=>'show'
  end

  # GET /carts/1/edit
  def edit
  end

  # POST /carts
  # POST /carts.json
  def create
    @cart = Cart.new(cart_params)

    respond_to do |format|
      if @cart.save
        format.html { redirect_to @cart, notice: 'Cart was successfully created.' }
        format.json { render action: 'show', status: :created, location: @cart }
      else
        format.html { render action: 'new' }
        format.json { render json: @cart.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /carts/1
  # PATCH/PUT /carts/1.json
  def update
    respond_to do |format|
      if @cart.update(cart_params)
        format.html { redirect_to @cart, notice: 'Cart was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @cart.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /carts/1
  # DELETE /carts/1.json
  def destroy
    @cart.destroy
    respond_to do |format|
      format.html { redirect_to carts_url }
      format.json { head :no_content }
    end
  end

  private
	def check_availability
		@feat = params[:id_feature]
		@item = current_cart.cartlistmaterials.find_by_technicalfeature_id(@feat)		
		@qty = params[:qty].to_i()
		borrowable_qty = Technicalfeature.find(@feat).borrowablequantity
		if (borrowable_qty < @qty) || (@item && borrowable_qty < @qty + @item.quantity)
			render :partial=>'show'
		end
	end
  
    # Use callbacks to share common setup or constraints between actions.
    def set_cart
      @cart = current_cart
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def cart_params
      params.permit(:id, :cart, :id_feature, :qty)
    end
end
