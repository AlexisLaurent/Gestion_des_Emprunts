class TechnicalfeaturesController < ApplicationController
  before_action :check_isadmin
  # GET /technicalfeatures
  # GET /technicalfeatures.json
  def index
     @technicalfeatures = Technicalfeature.all
     
     respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @technicalfeatures }
     end
  end

  # GET /technicalfeatures/new
  # GET /technicalfeatures/new.json
  def new
   @technicalfeature = Technicalfeature.new
   
    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @technicalfeature }
    end 
  end
  
  # GET /technicalfeatures/1/edit
  def edit
   @technicalfeature = Technicalfeature.find(params[:id])
  end

  # GET /technicalfeatures/13
  # GET /technicalfeatures/13.json
  def show
    @technicalfeature = Technicalfeature.find(params[:id])
    
    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @technicalfeature }
    end
  end

  # POST /technicalfeatures
  # POST /technicalfeatures.json
  def create
    @technicalfeature = Technicalfeature.new(technicalfeature_params)
    
    respond_to do |format|
      if @technicalfeature.save
        format.html { redirect_to @technicalfeature, notice: 'Technicalfeature was successfully created.' }
        format.json { render json: @technicalfeature, status: :created, location: @technicalfeature }
      else
        format.html { render action: "new" }
        format.json { render json: @technicalfeature.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /technicalfeatures/1
  # PUT /technicalfeatures/1.json
  def update
    @technicalfeature = Technicalfeature.find(params[:id])
 
    respond_to do |format|   
      if @technicalfeature.update_attributes(technicalfeature_params)
          format.html { redirect_to @technicalfeature, notice: 'Technicalfeature was successfully updated.' }
          format.json { head :no_content }
      else
         format.html { render action: "edit" }
         format.json { render json: @technicalfeature.errors, status: :unprocessable_entity }
      end   
    end 
  end

  # DELETE /technicalfeatures/1
  # DELETE /technicalfeatures/1.json 
  def destroy
    @technicalfeature = Technicalfeature.find(params[:id])
    @technicalfeature.destroy
    
    respond_to do |format|
      format.html { redirect_to technicalfeatures_url }
      format.json { head :no_content }
    end
  end
  
  def add
    tech = Technicalfeature.find(params[:id])
    all = Material.where(:technicalfeature => tech)
    a = all.count
    unusables = all.where(:materialstatus => Materialstatus.find_by_label("Inutilisable")).count
    res = a - unusables
    respond_to do |format|
      if tech.borrowablequantity < res
		tech.borrowablequantity = tech.borrowablequantity + 1
        tech.save
        format.json { render :json => {:status => " L'ajout a ete effectue avec succes.", :newqty => tech.borrowablequantity, :id=>params[:id], :reserve => a - tech.borrowablequantity} }
      else
        format.json { render :json => {:status => " Il n'y a pas assez de materiels disponibles pour effectuer l'ajout.", :newqty => tech.borrowablequantity, :id=>params[:id], :reserve => a - tech.borrowablequantity} }
      end
    end
  end
  
   def del
    tech = Technicalfeature.find(params[:id])
    all = Material.where(:technicalfeature => tech)
    bor = all.where(:materialstatus => Materialstatus.find_by_label("Emprunte")).count
    res = bor
    respond_to do |format|
      if res < tech.borrowablequantity
		tech.borrowablequantity = tech.borrowablequantity - 1
        tech.save
        format.json { render :json => {:status => " La suppression a ete effectuee avec succes.", :newqty => tech.borrowablequantity, :id=>params[:id], :reserve => all.count - tech.borrowablequantity} }
      else
        format.json { render :json => {:status => " Il n'y a pas assez de materiels disponibles pour effectuer la suppression.", :newqty => tech.borrowablequantity, :id=>params[:id], :reserve => all.count - tech.borrowablequantity}}
      end
    end
  end
  
  def all
    @res = Array.new
    Technicalfeature.where(:materialtype => Materialtype.find(params[:id])).each do |tech|
      mats = Material.where(:technicalfeature => tech)
      all = mats.count
      bor = mats.where(:materialstatus => Materialstatus.find_by_label("Emprunte")).count
      borrowable = tech.borrowablequantity
      reserve = all - borrowable
      unusable = mats.where(:materialstatus => Materialstatus.find_by_label("Inutilisable")).count
      @res << { :tech => tech, :qty => all, :reserve =>  reserve, :unusable =>  unusable, :borrow => bor }
    end

    respond_to do |format|
      format.json { render :json => @res }
    end
  end
  
  private
  
    def technicalfeature_params
      params.require(:technicalfeature).permit(:materialtype, :os, :name, :version, :memory, :ram, :processorfrequency)
    end
end
