class ApplicationController < ActionController::Base
  protect_from_forgery
  
    protected
    # Returns the currently logged in user or nil if there isn't one
    def current_user
      return unless session[:user_id]
      @current_user ||= User.find_by_id(session[:user_id])
    end
	# Returns the currents waiting requests
	def waiting_requests
		reqstatusid = Requeststatus.where(:label => "En attente")
		return Request.where(:requeststatus_id => reqstatusid).where(:user=>current_user)
	end
	# Returns the currents refused requests
	def refused_requests
		reqstatusid = Requeststatus.where(:label => "Refusee")
		return Request.where(:requeststatus_id => reqstatusid).where(:user=>current_user)
	end
	# Returns the currents pending requests
	def pending_requests
		reqstatusid = Requeststatus.where(:label => "En cours")
		return Request.where(:requeststatus_id => reqstatusid).where(:user=>current_user)
	end
	# Returns the currents finished requests
	def finished_requests
		reqstatusid = Requeststatus.where(:label => "Terminee")
		return Request.where(:requeststatus_id => reqstatusid).where(:user=>current_user)
	end
	# Returns the currents validated requests
	def validated_requests
		reqstatusid = Requeststatus.where(:label => "Validee")
		return Request.where(:requeststatus_id => reqstatusid).where(:user=>current_user)
	end
    
	# Returns the currently logged in user or nil if there isn't one
    def current_cart
      return unless session[:cart_id]
      @current_cart ||= Cart.find_by_id(session[:cart_id])
    end
	
	
    # Make available in templates as a helper
	helper_method :current_user	
    helper_method :current_cart
	helper_method :waiting_requests
    helper_method :refused_requests
	helper_method :pending_requests
	helper_method :finished_requests
	helper_method :validated_requests
	
	
    # Filter method to enforce a login requirement
    # Apply as a before_action on any controller you want to protect
    def authenticate
      logged_in? || access_denied
    end
    # Predicate method to test for a logged in user
    def logged_in?
      current_user.is_a? User
    end
    # Make logged_in? available in templates as a helper
    helper_method :logged_in?
    def access_denied
      redirect_to login_path, notice: "Please log in to continue" and return false
    end
    
    def check_isadmin 
      unless  current_user.admin?
        redirect_to root_path
      end
    end
    
end
