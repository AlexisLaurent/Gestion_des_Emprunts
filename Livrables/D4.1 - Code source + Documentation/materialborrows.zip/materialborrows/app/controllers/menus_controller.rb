class MenusController < ApplicationController

end
