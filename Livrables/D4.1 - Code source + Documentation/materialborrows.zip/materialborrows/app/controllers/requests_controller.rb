﻿class RequestsController < ApplicationController

	before_action :authenticate, except: [:request_type, :refuse_request, :create_mobile, :valide_request, :motive]
  before_action :check_isadmin, only: [:request_type]
  # GET /requests
  # GET /requests.json
  def index
    @requests = Request.all
    
     respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @requests }
     end
  end
  
  # GET /requests/13
  # GET /requests/13.json
  def show
    @request = Request.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @request }
    end    
  end

	def new	
	end
	
	def calendar
	end
	
	def create
	
      # Request
      @request = Request.new()
      @request.user = current_user
      @request.requeststatus = Requeststatus.find_by_label('En attente')
      @request.motivestatus = Motivestatus.find_by_label(params[:motive])
      
      @request.save
      
      # Materials
      current_cart.cartlistmaterials.each do |item|
        @techreq = Technicalfeaturesrequest.new()
        @techreq.technicalfeature_id = item.technicalfeature_id
        @techreq.request = @request
        @techreq.borrowedquantity = item.quantity
        @techreq.save
      end
      
      # Begin date 
      @complexdate_deb = Complexdate.new(deb_params)
      @complexdate_deb.request = @request 
      @complexdate_deb.complexdatetype = Complexdatetype.find_by_label('Emprunt debut')
      
      @complexdate_deb.save
      
      # End date  
      @complexdate_fin = Complexdate.new(fin_params)
      @complexdate_fin.request = @request 
      @complexdate_fin.complexdatetype = Complexdatetype.find_by_label('Emprunt fin')
  
      @complexdate_fin.save
      
      respond_to do |format|
          current_cart.clear
          #send e-mail to respo
          #Notifier.email_respo(@request, current_user.email).deliver
          format.html { redirect_to '/', notice: 'La requete a bien ete ajoute.' }
      end
  end
	
	def deb_params
   params.require(:complexdate_deb).permit(:cdate, :beginhour, :endhour)
	end
	
	def fin_params
   params.require(:complexdate_fin).permit(:cdate, :beginhour, :endhour)
  end
	
	def newtwo
		if(!current_cart.empty?)
		  @request = Request.new
		  @complexdate_deb = Complexdate.new
		  @complexdate_fin = Complexdate.new
		  @motivestatuses = Motivestatus.all
		else 
			redirect_to '/requests/new', notice: 'Votre panier est vide' 
    end
  end
	
  def manage
    
    case params[:status]
      when "waiting"
        @requeststatus = Requeststatus.find_by_label("En attente")
      when "pending"
        @requeststatus = Requeststatus.find_by_label("En cours")  
      when "refused"
        @requeststatus = Requeststatus.find_by_label("Refusee") 
      when "finished"
        @requeststatus = Requeststatus.find_by_label("Terminee")   
      when "validated"
        @requeststatus = Requeststatus.find_by_label("Validee")               
      else
        @requeststatus = Requeststatus.find_by_label("En attente")
    end
      
  end
  

  def update
    if params[:validate]
      #Mettre le status de la demande à "Validee"
      
      req = Request.find(params[:validate]) 
      status_validated= Requeststatus.find_by_label("Validee")
      req.requeststatus = status_validated
	    req.respobegin = current_user
      if req.update_attributes(request_params_validate)  
        redirect_to '/requests/manage/'
      else
        puts "***************Erreur update validate request_controller"
      end 
      
      
    elsif params[:recordborrow]
      #Mettre le status de la demande à "En cours"

      allMaterial = true
      matBarCode = true
      available_status = Materialstatus.find_by_label("Disponible")
      req = Request.find(params[:recordborrow]) 
     
      #Tableau du matériel choisi en fonction des codes barres
      materialArray = Array.new
      barCodeArray = params[:barCodeNumber]
      barCodeArray.each_with_index do |barCode, i|
        curMat = Material.find_by_barcode(barCode)
        if curMat != nil && curMat.materialstatus == available_status
          materialArray[i] = curMat 
        else
          puts "*************** materiel nul ou deja emprunte"
          matBarCode = false
        end
        
      end
      
      if matBarCode == false
        redirect_to '/requests/manage/', alert: 'Mauvais code barre.'
      else
        #Test si le matériel correspond bien au technicalfeature
        req.technicalfeaturesrequests.each do |techfeatreq|
          q = techfeatreq.borrowedquantity
          materialArray.each {|mat|
            
            if mat.technicalfeature == techfeatreq.technicalfeature
              q = q - 1
            end
          } 
               
          if q != 0
            allMaterial = false
          end
        end
          
        if allMaterial == false
          puts "*********************erreur materiel*************"
          #Le compte n'est pas bon ou erreur sur le matériel scanné
          redirect_to '/requests/manage/', alert: 'Mauvais code barre ou compte incomplet.'
        else
          
          #Si le matériel scanné correspond au matériel demandé
          
          materialArray.each {|mat|
            #Changer le status du matériel --> Emprunté
            borrowed_status = Materialstatus.find_by_label("Emprunte")
            mat.update_attributes(:materialstatus => borrowed_status)
          } 
          
          #Associer tout le matériel à la requête
          req.materials << materialArray
          
          #Changer le status de la demande --> En cours    
          status_pending= Requeststatus.find_by_label("En cours")
  
          req.update_attributes(:requeststatus => status_pending)
    
          #Tout s'est bien passé
          redirect_to '/requests/manage/'
        end        
      end

    elsif params[:materialreturned]
      req = Request.find(params[:materialreturned])  
      req.materials.each do |mat|
        if params[mat.barcode] != ""
          mat.update_attributes(:anomaly => params[mat.barcode])
        end
        #Changer le status du matériel --> Disponible
        available_status = Materialstatus.find_by_label("Disponible")
        mat.update_attributes(:materialstatus => available_status)
      end
      
      #Changer le status de la demande --> Terminée
      status_finished = Requeststatus.find_by_label("Terminee"); 
      req.update_attributes(:requeststatus => status_finished)
      
      redirect_to '/requests/manage/'
    else
      
      #Changer le status de la demande --> Refusée
      #Mettre à jour le motif de refus      
      req = Request.find(params[:id])    
      status_refused = Requeststatus.find_by_label("Refusee")
      req.requeststatus = status_refused
      if req.update_attributes(request_params)  
        redirect_to '/requests/manage/'
      else
        puts "******************Erreur update refuse request_controller************************"
        redirect_to '/requests/manage/', alert: 'Impossible de mettre à jour les attributs'
      end       
    end
  end
  
  def by_status
    @requests = Request.where(:requeststatus_id => params[:reqstatus_id]) 
    if !current_user.admin? 
      @requests = @requests.where(:user => current_user)
    end
       
    respond_to do |format|
      format.html { render :partial=>"by_status", :layout=>false  }
    end
  end
  
  def requestcomplet_finished
    @selectedrequest = Request.find_by_id(params[:req_id])
    respond_to do |format|
      format.html { render :partial=>"requestcomplet_finished", :layout=>false  }
    end
  end
  
  def requestcomplet_waiting
    @selectedrequest = Request.find_by_id(params[:req_id])
    respond_to do |format|
      format.html { render :partial=>"requestcomplet_waiting", :layout=>false  }
    end
  end
  
    def requestcomplet_pending
    @selectedrequest = Request.find_by_id(params[:req_id])
    respond_to do |format|
      format.html { render :partial=>"requestcomplet_pending", :layout=>false  }
    end
  end

  def requestcomplet_validated
    @selectedrequest = Request.find_by_id(params[:req_id])
    respond_to do |format|
      format.html { render :partial=>"requestcomplet_validated", :layout=>false  }
    end
  end

  def requestcomplet_refused
    @selectedrequest = Request.find_by_id(params[:req_id])
    respond_to do |format|
      format.html { render :partial=>"requestcomplet_refused", :layout=>false  }
    end
  end
  
  def requestcomplet
    @selectedrequest = Request.find_by_id(params[:req_id])
    respond_to do |format|
      format.html { render :partial=>"requestcomplet", :layout=>false  }
    end
  end 
  
  def request_type
    
    case params[:type]
    when "waiting"
      reqstatusid = Requeststatus.find_by_label("En attente")
    when "validated"
      reqstatusid = Requeststatus.find_by_label("Validee")
    when "refused"
      reqstatusid = Requeststatus.find_by_label("Refusee")
    when "pending"
      reqstatusid = Requeststatus.find_by_label("En cours")
    when "finished"
      reqstatusid = Requeststatus.find_by_label("Terminee")
    else
      # mouai
    end

    res = Array.new
    
    if (params.has_key?(:id))
      requests = Request.where(:requeststatus_id => reqstatusid).where(:user_id => params[:id])
    else
      requests = Request.where(:requeststatus_id => reqstatusid)
    end
    
    requests.each do |req|
      dates = Array.new
      materials = Array.new
      req.complexdates.each do |date|
        dates << {:date => date, :type => date.complexdatetype.label}
      end
      req.technicalfeaturesrequests.each do |techfeatreq| 
        materials << {:type => techfeatreq.technicalfeature.materialtype.label, :os => techfeatreq.technicalfeature.os, :name => techfeatreq.technicalfeature.name, :quantity => techfeatreq.borrowedquantity} 
      end
      res << {:id => req.id, :user_id => req.user_id, :firstname => req.user.firstname, :lastname => req.user.lastname, :motive => req.motivestatus.label, :dates => dates, :materials => materials}
    end

    respond_to do |format|
      format.json { render json: res}
    end
  end
  
  private
  
    def request_params_validate
      params.permit(:motivestatus_id, :requeststatus_id, :user_id)
    end
    def request_params
      params.require(:request).permit(:refusalmotive, :motivestatus_id, :requeststatus_id, :user_id)
    end
    
    
end
