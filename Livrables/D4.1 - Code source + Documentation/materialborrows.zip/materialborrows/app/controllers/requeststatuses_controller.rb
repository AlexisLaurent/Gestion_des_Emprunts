class RequeststatusesController < ApplicationController
end
