class MaterialtypesController < ApplicationController
  before_action :check_isadmin
  # GET /materialtypes
  # GET /materialtypes.json    
  def index
    @materialtypes = Materialtype.all

     respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @materialtypes }
     end    
  end

  def all
    materialstype = Materialtype.all.each do |item|
      {:id => item.id, :label => item.label}
    end

    respond_to do |format|
      format.json { render json: materialstype}
    end
  end
  
  def types
   @res = Array.new
   Materialtype.all.each do |m| 
     i = 0
     puts m.label
     tech = Technicalfeature.where(:materialtype => m)
     tech.each do |t|
       puts tech
       mat =  Material.where(:technicalfeature => t)
       puts mat
       i = i + mat.count
     end 
     @res << { :id => m.id ,:type => m.label, :qty => i}
   end
   
   respond_to do |format|
      format.json { render json: @res}
    end
  end
  
end
