module ApplicationHelper

end
