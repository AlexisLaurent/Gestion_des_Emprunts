module TechnicalfeaturesHelper
end
