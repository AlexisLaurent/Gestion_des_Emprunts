// Occurs when adding an item to the shopping cart
function clearCart(event) {
	// Stop the event dispatching
	event.defaultPrevented;
	
	// Call the add action of the controller
	return $.ajax({
		url: '/carts/clear',
		type: 'GET',
		data: {
			qty: 1
		},
		success: function(result) {
			$(".cart").replaceWith(result);
		},
		error: function(event, data, status, xhr) {
			console.log("KO adding to shopping cart");
		}
		});	
}

// Occurs when the user wants to remove an item of the current cart
function removeItemFromCart(event, techId, quantity) {
	// Stop the event dispatching
	event.defaultPrevented;
	
	// Call the add action of the controller
 	return $.ajax({
		url: '/carts/remove',
		type: 'GET',
		data: {
			id_feature: techId,
			qty: quantity
		},
		success: function(result) {
			$(".cart").replaceWith(result);
		},
		error: function(event, data, status, xhr) {
			console.log("KO removing to shopping cart");
		}
	});	 
}

// Occurs when adding an item to the shopping cart
function addToShoppingCart(event, id) {
	
	// Stop the event dispatching
	event.defaultPrevented;
	
	// Call the add action of the controller
	return $.ajax({
		url: '/carts/add',
		type: 'GET',
		data: {
			id_feature: id,
			qty: 1
		},
		success: function(result) {
			$(".cart").replaceWith(result);
		},
		error: function(event, data, status, xhr) {
			console.log("KO adding to shopping cart");
		}
		});	
}