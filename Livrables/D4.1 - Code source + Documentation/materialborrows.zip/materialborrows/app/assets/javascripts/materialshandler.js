(function($, undefined){

	var $window = $(window);
	
	var Section = function (id, content) {
		this.content = content;
		this.id = id;
	}
	
	Section.prototype = {
		constructor: Section,
		getTitle: function(){
			return this.content.find('.panel-title a');
		},
		getBody: function(){
			return this.content.find('.panel-body');
		},
	};
	
	// Materials handler object
	
	var Materialshandler = function(element, options){
	
		this._process_options(options);	
		this.element = $(element);
		this.handler = $(Graphics.template);
		//this.setNbOfSections(this.o.nbOfSections);
		this.sections = this.bindData(this.o.materialTypesPath);
		this.fill();
		
		this.handler.appendTo(this.element);
		this.show();
	}
	
	// Materialshandler Prototype
	
	Materialshandler.prototype = {
		constructor: Materialshandler,
		_process_options: function(opts){
			this._o = $.extend({}, this._o, opts);
			var o = this.o = $.extend({}, this._o);
		},
		setNbOfSections: function(nbOfSections){
			this._process_options({nbOfSections: nbOfSections});
		},
		show: function(){
			this.handler.show();
		},
		hide: function(){
			this.handler.hide();
		},
		bindData: function(path) {
			// Call the add action of the controller
			return $.ajax({
				url: path,
				type: 'GET',
				async: false,
				success: function(result) {
					return result.sections;
				},
				error: function(event, data, status, xhr) {
					console.log("Error(s) when loading data from " + path);
				}
			}).responseJSON;
		},
		displayMaterial: function(barcode){
			var td = $('#barcode_'+barcode);
			if( td !== undefined  ) {
				var feature_row = $(td.parent().parent().parent().parent().parent().parent().prev()[0]);
				var panel = feature_row.parent().parent().parent().parent().parent().parent();
				if(!panel.find(".panel-collapse").hasClass("in")) panel.find('a').trigger('click');
				if(!$(feature_row.next()[0]).hasClass("in")) $(feature_row.children()[0]).trigger('click');
				var row = $(td.parent());
				row.addClass("highlighted");
				setInterval(function(){myTimer(row)},5000);

				function myTimer(param)
				{
					param.removeClass("highlighted");
				}
			}				
		},
		fill: function(){
			var section;
			var i;
			for (i=0; i<this.sections.length; i++) {
				// first level of depth
				var id = "section_" + this.sections[i].id;
				var section = new Section(this.sections[i].id, $(Graphics.section));
				var title = section.getTitle('.panel-title a');
				var body = section.getBody('.panel-body');
				var href = "#" + id;
				section.content.attr("value", this.sections[i].id);
				title.html(this.sections[i].type + "<small> (Total : " + this.sections[i].qty + ")</small>");
				title.attr("href", href);
				section.content.find('.panel-collapse').attr("id", id);
				
				// second level of depth
				var features = this.bindData(this.o.technicalFeaturesPath + this.sections[i].id);
				var table = "<div class='table-responsive'><table class='table table-condensed'>";
				table += "<tr><th>Nom</th><th>Os</th><th>Version</th><th>RAM</th><th>Stockage<small> (Go)</small></th><th>Empruntables</th><th>R&eacute;serve</th><th>Empruntés</th><th>Inutilisables</th><th>Total</th></tr>";
				var row, feature, feature_id, j;
				for(j=0 ; j<features.length; j++) {
					feature = features[j].tech;
					feature_id = "feature_" + feature.id;
					row = "<tr>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + feature.name + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + feature.os + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + feature.version + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + feature.ram + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + feature.memory + "</td>";
					row += "<td><small><span class='pointable glyphicon glyphicon-minus' onclick='handleBorrowableQuantity(event, " + "\"" + this.o.removeBorrowablePath + "\", " + feature.id + ");" + "'></span></small> <strong id='borrowableQtyNumber_" + feature.id + "'>" + feature.borrowablequantity + "</strong> <small><span class='pointable glyphicon glyphicon-plus' onclick='handleBorrowableQuantity(event, " + "\"" + this.o.addBorrowablePath + "\", " + feature.id + ");" + "'></span></small></td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle' id='reserved_" + feature.id + "'>" + features[j].reserve + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + features[j].borrow + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + features[j].unusable + "</td>";
					row += "<td data-toggle='collapse' data-target='#" + feature_id + "' class='accordion-toggle'>" + features[j].qty + "</td>";
					row += "</tr>";
					table += row;
					
					// third level of depth
					row = "<tr id='" + feature_id + "' class='accordian-body collapse'>";
					row += "<td colspan='9'>";
					var materials = this.bindData(this.o.materialsPath + feature.id);
					var tableMat = "<div class='table-responsive'><table class='table table-condensed materials'>";
					tableMat += "<tr><th>Num&eacute;ro de s&eacute;rie</th><th>Fin de garantie</th><th>Anomalie</th><th>Statut</th><th>Propri&eacute;taire</th><th>Code barre</th><th>Emprunteur</th>";
					var rowMat, mat, k;
					for(k=0 ; k<materials.length; k++) {
						mat = materials[k].mat;
						rowMat = "<tr>";
						rowMat = (mat.anomaly == "Aucune") ? "<tr>" : "<tr class='warning'>";
						rowMat = (materials[k].status == "Emprunte") ? "<tr class='success'>" : rowMat;
						rowMat = (materials[k].status == "Inutilisable") ? "<tr class='danger'>" : rowMat;
						rowMat += "<td>" + mat.serialnumber + "</td>";
						rowMat += "<td>" + mat.guaranteeend + "</td>";
						rowMat += "<td>" + mat.anomaly + "</td>";
						rowMat += "<td>" + materials[k].status + "</td>";
						rowMat += "<td>" + mat.whobought + "</td>";
						rowMat += "<td id='barcode_" + mat.barcode + "'>" + mat.barcode + "</td>";
						rowMat += (materials[k].status == "Emprunte") ? "<td><small>" + materials[k].borrower.firstname + " " + materials[k].borrower.lastname + "</small> <a href='mailto:" + materials[k].borrower.email + "'>" + materials[k].borrower.email + "</a></td>" : "<td><small><em>(Aucun emprunt en cours)</em></small></td>";
						rowMat += "</tr>";
						tableMat += rowMat;
					}
					tableMat += "</table></div>";
					row += tableMat + "</td></tr>";
					table += row;
				}
				table += "</table></div>";
				section.content.find('.panel-body').html(table);
				
				this.handler.find('#accordion').append(section.content);
			}
		},
	};
	
	var old = $.fn.materialshandler;
	$.fn.materialshandler = function(option){
		var args = Array.apply(null, arguments);
		args.shift();
		var internal_return;
		this.each(function(){
			var $this = $(this),
				data = $this.data('materialshandler'),
				options = typeof option === 'object' && option;
			if (!data){
					var opts = $.extend({}, defaults, options);
					$this.data('materialshandler', (data = new Materialshandler(this, opts)));
			}
 			if (typeof option === 'string' && typeof data[option] === 'function'){
				internal_return = data[option].apply(data, args);
				if (internal_return !== undefined)
					return false;
			}
		});
		if (internal_return !== undefined)
			return internal_return;
		else
			return this;
	};
	
	var defaults = $.fn.materialshandler.defaults = {
		nbOfSections: 3,
		materialTypesPath: "/materialtypes/types",
		technicalFeaturesPath: "/technicalfeatures/all/",
		addBorrowablePath: "/technicalfeatures/add/",
		removeBorrowablePath: "/technicalfeatures/del/",
		materialsPath: "/materials/all/",
	};
	
	var Graphics = {
		root: "<div class='panel-group' id='accordion'></div>",
		section_title: "<h4 class='panel-title'>" +
						"<a data-toggle='collapse' data-parent='#accordion'></a>" +
					  "</h4>",
		section_body: "<div class='panel-collapse collapse out'>" +
						"<div class='panel-body'>" +
						"</div>" +
					   "</div>",
	};
	
	Graphics.section =  "<div class='panel panel-default'>" +
							"<div class='panel-heading'>" +
								Graphics.section_title +
							"</div>" +
								Graphics.section_body +
						  "</div>";
	Graphics.template = '<div class="materialshandler">'+
							Graphics.root +
						'</div>';

	$.fn.materialshandler.Graphics = Graphics;	
	$.fn.materialshandler.Constructor = Materialshandler;
	
}(window.jQuery));