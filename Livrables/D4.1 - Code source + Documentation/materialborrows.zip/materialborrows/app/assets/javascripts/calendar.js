﻿var current_year;
var month = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
var month_position = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
var month_end = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
var current_month;
var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
var day_position = [0, 1, 2, 3, 4, 5, 6];
var days_number_to_show = 14;
var current_day, current_day_position;
var centered_highlighted_day_position = 2;
var hours = [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];
var requestStartDate=-1, requestEndDate=-1;
var calendar;

function initCalendar() {
	var today = new Date();	
	current_month = today.getMonth();
	current_day = today.getDate();
	current_year = today.getFullYear();
	current_day_position = today.getDay();
	// Bissextile year figures
	month_end[1] = ((current_year%4==0 && current_year%100!=0) || (current_year%400==0)) ? 29 : 28;
	if( $(".calendar").length > 0 ) $(".calendar *").remove();
	calendar = new Calendar($('.calendar'), false);
} 

function reinitCalendar() {
	if( $(".calendar").length > 0 ) $(".calendar *").remove();
	calendar = new Calendar($('.calendar'), false);
} 


// This is the constructor of the calendar
function Calendar(DOMTree, showWE) {
	this.showWE = showWE;
	this.DOMTree = DOMTree;
	$(this).bind("go!", function() {console.log("Show WE: " + this.showWE);});
	
	$('.calendar').append("<div class='row'><div class='col-md-8'><h3 class='currentMonth pull-left'>&nbsp;</h3></div><div id='changeCalendarView' class='btn-group col-md-4 pull-right'><div class='pull-right'><button type='button' class='btn btn-default' value='7'>Semaine</button><button type='button' class='btn btn-default' value='14'>14 jours</button><button type='button' class='btn btn-default' value='30'>Mois</button></div></div></div>");
	$('.calendar').append("<div class='row'><table class='table table-bordered days'></table><button type='button' class='btn-icon btn btn-default btn-md' onClick='previous(days_number_to_show);'><span class='pointable glyphicon glyphicon-backward'></span></button><button type='button' class='btn-icon btn btn-default btn-md' onClick='previous(1);'><span class='pointable glyphicon glyphicon-chevron-left'></span></button><button type='button' class='btn-icon btn btn-default btn-md' onClick='next(1);'><span class='pointable glyphicon glyphicon-chevron-right'></span></button><button type='button' class='btn-icon btn btn-default btn-md' onClick='next(days_number_to_show);'><span class='pointable glyphicon glyphicon-forward'></span></button></div>");
	var html="";
	for (var i=0; i<days_number_to_show; i++) {
		html += "<th class='col-sm-1'>&nbsp;</th>";
	}
	$('.days').append("<tr class='daysRow'>"+html+"</tr>");	
	hours.forEach(function(h) {
		html="";
		for (var i=0; i<days_number_to_show; i++) {
			html += "<td class='slot' value='" + h + "' onclick=\"setSlot(this)\">" + "<section href='#' rel='tooltip' container='body' data-toggle='popover' data-placement='top' title='Créneau de " + h + "h à " + (h+1) + "h'>&nbsp;</section>" + "</td>";
		}
		$('.days').append("<tr value='" + h + "'>"+html+"</tr>");
	});
	
	refresh();
	
    $("[rel=tooltip]").tooltip();
	$(".calendar #changeCalendarView button").click(function() {
		days_number_to_show = parseInt(this.value);
		reinitCalendar();
	});
}

function refresh() {
	loadCalendar(current_day, current_day_position);
}

function refreshCalendar(date) {
	current_day = date.getDate();
	current_month = date.getMonth();
	current_year = date.getFullYear();
	current_day_position = date.getDay();
	refresh();
}

// Load the entire calendar
// @params:
//		startDayNumber: the day which has been chosen
//		startDayPosition: the day position in a week which has been chosen (ie. [0]=>Monday, [1]=>Tuesday...)
function loadCalendar(startDayNumber, startDayPosition) {
	var date = new Date(current_year, current_month, current_day);
	var tmp;
	var daysFirstRow = "";
	var t = $(".daysRow").children();
	$(".currentMonth")[0].innerHTML = month[current_month] + " <small>" + current_year + "</small>";
	
	// Load day by day starting with @startDayNumber-centered_highlighted_day_position
	for(var i=-centered_highlighted_day_position; i<-centered_highlighted_day_position+days_number_to_show; i++) {
		tmp = new Date(current_year, current_month, current_day);
		tmp.setDate(date.getDate() + i);
		if (i==0) t[i+centered_highlighted_day_position].innerHTML = "<strong class='orange'>" + days[tmp.getDay()] + " " + tmp.getDate() + "</strong>";
		else t[i+centered_highlighted_day_position].innerHTML = "<small>" + days[tmp.getDay()] + " " + tmp.getDate() + "</small>";
		t[i+centered_highlighted_day_position].id = "d"+tmp.getDate()+""+tmp.getMonth();
		t[i+centered_highlighted_day_position].title = tmp;
		
		
		// Load the current day
		loadOneDay(tmp.getDate(), tmp.getMonth()+1, i+centered_highlighted_day_position);
	}
}

// Load the appropriate HTML for a day position passed in params
// @params:
//		dayNumber: the number of the day according to the month
//		dayPosition: the day position in a week
function loadOneDay(dayNumber, monthNumber, HTMLcolumnNumber) {
	refreshDay(dayNumber, monthNumber, HTMLcolumnNumber);
}

// Refreshed the data of a day (AJAX call)
// @params:
//		date: the date object representing the day
function refreshDay(dayNumber, monthNumber, HTMLcolumnNumber) {
	// Call the add action of the controller 
	return $.ajax({
		url: '/materials/check_available.json',
		type: 'GET',
		dataType: 'json',
		data: {
			day: dayNumber,
			month: monthNumber,
			year: current_year
		},
		success: function(result) {	
			var index = $(".days #" + "d" + result.day +""+ result.month).index();
			var features = result.features;
			var percent = 0, borrowed = 0, borrowable = 0;
			var unborrowableArray = [];
			
			// Iterate on all the features
			result.features.forEach(function(feature) {
			//console.log(feature.name + ": (feature.alreadyBorrowed + feature.wantedQty)=" + feature.alreadyBorrowed + "+" + feature.wantedQty + "=" + (feature.alreadyBorrowed + feature.wantedQty) + " | borrowableQty=" + feature.borrowableQty);
				if ((feature.alreadyBorrowed + feature.wantedQty) > feature.borrowableQty) {
					percent=100;
					unborrowableArray.push(feature);
				}
				else {
					borrowed += feature.alreadyBorrowed+feature.wantedQty;
					borrowable += feature.borrowableQty;
				}
			});
			
			// Set the current percent (for the color indicator)
			percent = (percent < 100 && borrowable > 0) ? (borrowed*100/borrowable) : percent;
			var ratio = percent/100;
			
			// Get RGB
			var b = 0;
			var r = parseInt(Math.max(255 * ratio, 100));
			var g = (ratio==1) ? 0 : 255;
			
			// Set the color
			$(".days tr td:nth-child("+(index+1)+")").css('background-color', "rgb("+r+","+g+","+b+")");
			//if(percent == 100) $(".days tr td:nth-child("+(index+1)+") section").attr('data-original-title', unborrowableArray[0].name + " | " + (unborrowableArray[0].alreadyBorrowed + unborrowableArray[0].wantedQty - unborrowableArray[0].borrowableQty) + " en trop");
		},
		error: function(event, data, status, xhr) {
			console.log(event + " # " +  data);
		}
	});	
}

function previous(d) {
	var date = new Date(current_year, current_month, current_day);
	date.setDate(date.getDate() - d);
	refreshCalendar(date);
}

function next(d) {
	var date = new Date(current_year, current_month, current_day);
	date.setDate(date.getDate() + d);
	refreshCalendar(date);
}


function setSlot(e) {
	// Set the slot of the active date
	var date = $(e).closest('table').find('th').eq($(e).index()).attr('title');
	var hour = $(e).attr('value');
	var beginhour, endhour;
	
	// Set the complete cate with the hour from the cell
	var dateClicked = new Date(date);
	dateClicked.setHours(hour);
	
	// Update the date in the little date pickers
	if(dateClicked.getDay() != 0) { // on Sunday
		if(requestStartDate == -1) {
			beginhour = $("#little_calendars #detailstart .beginhour");
			endhour = $("#little_calendars #detailstart .endhour");
			beginhour.val(getObeforeDateOrHour(hour) + ":00");
			endhour.val(getObeforeDateOrHour((parseInt(hour)+1)) + ":00");
			$('.datepicker1').datepicker('setDate', dateClicked);
			$('.datepicker1').datepicker('update', new Date(dateClicked.getFullYear(), dateClicked.getMonth(), dateClicked.getDate()));			
			requestStartDate = dateClicked;
			//$(e).html("<strong>D</strong>");
		}
		else if (dateClicked > requestStartDate) {
			beginhour = $("#little_calendars #detailend .beginhour");
			endhour = $("#little_calendars #detailend .endhour");
			beginhour.val(getObeforeDateOrHour(hour) + ":00");
			endhour.val(getObeforeDateOrHour((parseInt(hour)+1)) + ":00");
			$('.datepicker2').datepicker('setDate', dateClicked);
			$('.datepicker2').datepicker('update', new Date(dateClicked.getFullYear(), dateClicked.getMonth(), dateClicked.getDate()));
			requestEndDate = dateClicked;
			//$(e).html("<strong>F</strong>");
		}
	}
}

function error() {
}

function getObeforeDateOrHour(value) {
	return (value < 10) ? '0'+value : value;
}

function setLittleCalendarsBehaviour() {
	$('#little_calendars .datepicker1').datepicker("setDaysOfWeekDisabled", '0');
	$('#little_calendars .datepicker2').datepicker("setDaysOfWeekDisabled", '0');
	
	$('#little_calendars .datepicker1').datepicker().on("changeDate", function(e){
		refreshCalendar(e.date);
		$(".dateSummary")[0].innerHTML = e.date.getDate() + " " + month[e.date.getMonth()] + " " + e.date.getFullYear();
		$('#little_calendars .datepicker2').datepicker("setStartDate", e.date);
		
		// set the value of the hidden form field
		var m = getObeforeDateOrHour(e.date.getMonth()+1);
		$("#complexdate_deb_cdate").val(e.date.getFullYear() + '-' + m + '-' + getObeforeDateOrHour(e.date.getDate()));
		$(".dateSummary")[1].innerHTML = "(aucune)";
		$("#complexdate_fin_cdate").val("jj/mm/aaaa");
		
		// set the start hours in the summary
		$('#startHourSummary').html("entre " + $("#beginhour_begin").val() + "h et " + $("#endhour_begin").val() + "h");
	});
	$('#little_calendars .datepicker2').datepicker().on("changeDate", function(e){
		refreshCalendar(e.date);
		$("#complexdate_fin_cdate").val(e.date);
		$(".dateSummary")[1].innerHTML = e.date.getDate() + " " + month[e.date.getMonth()] + " " + e.date.getFullYear();
		
		// set the value of the hidden form field
		var m = getObeforeDateOrHour(e.date.getMonth()+1);
		$("#complexdate_fin_cdate").val(e.date.getFullYear() + '-' + m + '-' + getObeforeDateOrHour(e.date.getDate()));
		
		// set the end hours in the summary
		$('#endHourSummary').html("entre " + $("#beginhour_end").val() + "h et " + $("#endhour_end").val() + "h");
	});
	
	// This function checks if all the required field have been filled out
	function validateRequestForm()
	{
		var beginDate=document.forms["commit"]["begin"].value;
		var endDate=document.forms["commit"]["end"].value;
		if (beginDate==null || beginDate=="")
		{
		  alert("Vous devez renseigner une date de début");
		  return false;
		}
	}
}