// Show a material in details or a form to add it
function check_barcode(val) {
  	event.preventDefault();
      $.ajax({
        url: '/materials/check_material',
        type: 'GET',
        data: {
          barcode : val
        },
	  	success: function(result) {
			$("#material_view").html(result);
			 if ($('#type') !== undefined){
			 	complete("");
			 }
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur !!!");
		  }
 	 });
 }

function edit_material(val, barcode) {
  	event.preventDefault();
      $.ajax({
        url: '/materials/add_material',
        type: 'GET',
        data: {
          id : val,
          barcode : barcode
        },
	  	success: function(result) {
			$("#material_view").html(result);
			 if ($('#type') !== undefined){
			 	complete($('#type').val());
			 }
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur !!!");
		  }
 	 });
 }
 
 function del_material(val) {
  	event.preventDefault();
      $.ajax({
        url: '/materials/del_material',
        type: 'GET',
        data: {
          id : val
        },
	  	success: function(result) {
			$("#material_view").html(result);
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur !!!");
		  }
 	 });
 }
 
 function show_material(val) {
	event.preventDefault();
      $.ajax({
        url: '/materials/show_material',
        type: 'GET',
        data: {
          barcode : val
        },
	  	success: function(result) {
			$("#material_view").html(result);
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur !!!");
		  }
 	 });
 }

function complete(val) {
  	event.preventDefault();
      $.ajax({
        url: '/materials/autocomplete',
        type: 'GET',
        data: {
          type : val
        },
	  	success: function(result) {
	  		$("#type").autocomplete({
				source: result[0],
				change: function( event, ui ) {
					complete( $("#type").val());
				},
				select: function(event, ui) {
		          	$("#type").val(ui.item.value);
		        },
   			}),
			$("#name").autocomplete({
				source: result[1]
   			}),
   			$("#os").autocomplete({
				source: result[2]
   			}),
   			$("#version").autocomplete({
				source: result[3],
   			}),
   			$("#memory").autocomplete({
				source: result[4],
   			}),
   			$("#ram").autocomplete({
				source: result[5],
   			}),
   			$("#processorfrequency").autocomplete({
				source: result[6],
   			}),
   			$("#whobought").autocomplete({
				source: result[7],
   			});
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur !!!");
		  }
 	 });
 }