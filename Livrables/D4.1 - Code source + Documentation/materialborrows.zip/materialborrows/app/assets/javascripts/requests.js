function checkUserRequest(startDate, startHour1, startHour2, endDate, endHour1, endHour2) {
	startDate = new Date(startDate);
	endDate = new Date(endDate);
	
	// Call the add action of the controller 
	return $.ajax({
		url: '/materials/check_period.json',
		type: 'GET',
		dataType: 'json',
		data: {
			startDay: startDate.getDate(),
			startMonth: startDate.getMonth()+1,
			startYear: startDate.getFullYear(),
			hour1Start: startHour1,
			hour2Start: startHour2,
			stopDay: endDate.getDate(),
			stopMonth: endDate.getMonth()+1,
			stopYear: endDate.getFullYear(),
			hour1End: endHour1,
			hour2End: endHour2
		},
		success: function(result) {	
			console.log(result.notice);
		},
		error: function(event, data, status, xhr) {
			console.log(event + " # " +  data);
		}
	});
}


function initCheckboxesMaterialTypes() {
	var ckbxs = $("*:checkbox");
	for (i=0; i<ckbxs.length; i++)
	{
		ckbxs[i].addEventListener('change', function(event, data, status, xhr) {
		event.preventDefault();
		$("#bottomrow").css("display","none");
		$(".overlay").css("display","inline-block");
		var ckbxs = $("*:checkbox");
		var ids = [];
		for (i=0; i<ckbxs.length; i++)
		{
			if (ckbxs[i].checked) ids.push(ckbxs[i].id);
		}
		return $.ajax({
		  url: '/materials/by_type',
		  type: 'GET',
		  data: {
			ids: ids
		  },
		  success: function(result) {
				$("#material_list_view").html(result);
				$(".overlay").css("display","none");
				$("#bottomrow").css("display","inline-block");
		  },
		  error: function(event, data, status, xhr) {
				console.log("KO get mat by type");
				$(".overlay").css("display","none");
		  }
		});
	  });
	}
	$("*:checkbox :first-child").trigger('change');
}


// Show a request in details
function show_request(event, object) {
  	event.preventDefault();
      $.ajax({
        url: '/requests/requestcomplet',
        type: 'GET',
        data: {
          req_id : object.value
        },
	  	success: function(result) {
			$("#request_complet_view").html(result);
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur dans _by_status.html.erb");
		  }
 	 });
}
 

function checkBarCode(object, barcode, txtbarcode)
{
	if (object.value == barcode){
		$(object).closest('tr').find('td:first span').css("display","inline");
		$('input[name='+ txtbarcode.name + ']').attr('checked', true);
		var allCheck = true;
		$('input[type=checkbox]').each(function () {
		    allCheck = this.checked ? true: false;
		});
		if(allCheck){
			$('#buttonmaterialreturned').prop('disabled', false);
		}
	}
	else{
		$(object).closest('tr').find('td:first span').css("display","none");
		$('input[name='+ txtbarcode.name + ']').attr('checked', false);
		$('#buttonmaterialreturned').prop('disabled', true);
	}
}

function setComplexDate(time, periode) {
	if( time == "am"){
		$("#beginhour_" + periode).val("08:00");
		$("#endhour_" + periode).val("12:15");
	} else {
		$("#beginhour_" + periode).val("13:30");
		$("#endhour_" + periode).val("17:45");
	}
}