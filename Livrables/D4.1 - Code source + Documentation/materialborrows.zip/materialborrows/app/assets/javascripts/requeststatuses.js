function initRequestStatusChange(reqstatusid) {
	
	$('#statuses_select').change(function(event) {
    		event.preventDefault();
	      	$.ajax({
		        url: '/requests/by_status',
		        type: 'GET',
	        	data: { 
	        		reqstatus_id : $('#statuses_select').val() 
	    		},
		  		success: function(result) {
					$("#request_list_view_by_status").html(result);
		  		},
			  	error: function(event, data, status, xhr) {		  		
					console.log(data);
		  		}
	      	});
    	});
    	
	$("#statuses_select option[value='" + reqstatusid.toString() + "']").attr('selected','selected');
	$('#statuses_select').change();
}