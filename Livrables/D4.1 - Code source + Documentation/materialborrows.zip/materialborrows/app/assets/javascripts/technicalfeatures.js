function handleBorrowableQuantity(e, path, feature_id) {
	// Stop the event dispatching
	e.defaultPrevented;
	
	// Call the add action of the controller
	return $.ajax({
		url: path+feature_id,
		type: 'GET',
		success: function(result) {
			var borrowable_id = "#borrowableQtyNumber_" + result.id;
			var reserved_id = "#reserved_" + result.id;
			$(".materialshandler " + borrowable_id).html(result.newqty);
			$(".materialshandler " + reserved_id).html(result.reserve);
		},
		error: function(event, data, status, xhr) {
			console.log("Error(s) when loading data from " + path);
		}
	}).responseJSON;
}