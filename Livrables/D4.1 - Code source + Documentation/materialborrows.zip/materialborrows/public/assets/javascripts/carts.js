// Occurs when adding an item to the shopping cart
function clearCart() {
	// Stop the event dispatching
	event.preventDefault();
	
	// Call the add action of the controller
	return $.ajax({
		url: '/carts/clear',
		type: 'GET',
		data: {
			qty: 1
		},
		success: function(result) {
			$(".cart").replaceWith(result);
		},
		error: function(event, data, status, xhr) {
			console.log("KO adding to shopping cart");
		}
		});	
}