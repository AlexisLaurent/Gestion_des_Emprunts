document.addEventListener('DOMContentLoaded', function () {
	var ckbxs = $("*:checkbox");
	for (i=0; i<ckbxs.length; i++)
	{
		ckbxs[i].addEventListener('change', function(event, data, status, xhr) {
		event.preventDefault();
		$("#bottomrow").css("display","none");
		$(".overlay").css("display","inline-block");
		var ckbxs = $("*:checkbox");
		var ids = [];
		for (i=0; i<ckbxs.length; i++)
		{
			if (ckbxs[i].checked) ids.push(ckbxs[i].id);
		}
		return $.ajax({
		  url: '/materials/by_type',
		  type: 'GET',
		  data: {
			ids: ids
		  },
		  success: function(result) {
				$("#material_list_view").html(result);
				$(".overlay").css("display","none");
				$("#bottomrow").css("display","inline-block");
		  },
		  error: function(event, data, status, xhr) {
				console.log("KO get mat by type");
				$(".overlay").css("display","none");
		  }
		});
	  });
	}
    
});

// Occurs when adding an item to the shopping cart
function addToShoppingCart(item_clicked) {
	
	// Stop the event dispatching
	event.preventDefault();
	
	// Call the add action of the controller
	return $.ajax({
		url: '/carts/add',
		type: 'GET',
		data: {
			id_feature: item_clicked.id,
			qty: 1
		},
		success: function(result) {
			$(".cart").replaceWith(result);
		},
		error: function(event, data, status, xhr) {
			console.log("KO adding to shopping cart");
		}
		});	
}

// Show a request in details
function show_request(object) {
  	event.preventDefault();
  	console.log(object);
      $.ajax({
        url: '/requests/requestcomplet',
        type: 'GET',
        data: {
          req_id : object.value
        },
	  	success: function(result) {
			$("#request_complet_view").html(result);
	  	},
		error: function(event, data, status, xhr) {
		  	console.log("Erreur dans _by_status.html.erb");
		  }
 	 });
 }